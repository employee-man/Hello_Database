package com.example.hello_database

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
