import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

void main()async {
    WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    // Replace with actual values
    options: const FirebaseOptions(
      apiKey: "AIzaSyAROiDVd7py0qHZrIgVmLFskWtR69pxdT8",
      appId: "1:882110065507:web:787183398a2c5200e94156",
      messagingSenderId: "882110065507",
      projectId: "hello-database-d48a0",
    ),
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  String _displayText = "Loading";

  @override
  void initState() {
    super.initState();
    _fetchText();
  }

  void _fetchText() {
    _firestore.collection('Content').doc('displayText').snapshots().listen((snapshot) {
      if (snapshot.exists) {
        setState(() {
          _displayText = snapshot.data()?['text'] ?? 'No data';
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Firestore Text Display'),
      ),
      body: Center(
        child: Text(
          _displayText,
          style: const TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}
